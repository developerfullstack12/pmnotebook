<div class="tabs-content">
    <h3><?php _e( 'How does BuddyBoss subscriptions work?', 'buddyboss-theme' ); ?></h3>
    <p><?php _e( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras porttitor placerat ipsum. Maecenas venenatis euismod urna pretium faucibus. Fusce at interdum neque, vitae cursus augue. In ac dignissim mi. Quisque et nulla commodo, elementum dui at, tempus magna. Nam fringilla ac ipsum non tempor.', 'buddyboss-theme' ); ?>
    </p>
    <iframe width="560" height="315" src="https://www.youtube.com/embed/ScMzIvxBSi4" frameborder="0"
            allowfullscreen></iframe>
    <p><?php _e( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras porttitor placerat ipsum. Maecenas venenatis euismod urna pretium faucibus. Fusce at interdum neque, vitae cursus augue. In ac dignissim mi. Quisque et nulla commodo, elementum dui at, tempus magna. Nam fringilla ac ipsum non tempor.', 'buddyboss-theme' ); ?>
    </p>
</div>