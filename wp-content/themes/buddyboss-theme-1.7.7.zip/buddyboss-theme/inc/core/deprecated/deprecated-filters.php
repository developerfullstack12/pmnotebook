<?php
/**
 * Deprecated Filters of BuddyBoss Theme.
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
