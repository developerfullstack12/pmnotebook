<?php
/**
 * Templates Modal Container
 */
?>
<div id="bbelementor-modal-templates-container"></div>