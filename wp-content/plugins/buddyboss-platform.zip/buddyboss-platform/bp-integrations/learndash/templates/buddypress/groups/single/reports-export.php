<div class="bp-learndash-group-courses-export-csv">
	<a href="#" class="button small ld-report-export-csv">
		<?php _e( 'Export CSV', 'buddyboss' ); ?>
	</a>
	<span class="export-indicator">
		<span class="export-current-step"></span>/<span class="export-total-step"></span>
	</span>
</div>
