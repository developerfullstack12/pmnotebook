<p><?php _e( 'Oops! That page can’t be found.', 'buddyboss' ); ?></p>
