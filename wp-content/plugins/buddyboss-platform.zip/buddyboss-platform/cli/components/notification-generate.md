#	wp bp notification generate

Generate random notifications.

## OPTIONS

[--count=&lt;number&gt;]
: How many notifications to generate.
\---
default: 100
\---

## EXAMPLE

    $ wp bp notification generate --count=50
