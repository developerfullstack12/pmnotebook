#	wp bp signup delete

Delete a signup.

## OPTIONS

&lt;signup-id&gt;...
: ID or IDs of signup.

[--yes]
: Answer yes to the confirmation message.

## EXAMPLES

    $ wp bp signup delete 520
    Success: Signup deleted.

    $ wp bp signup delete 55654 54564 --yes
    Success: Signup deleted.
