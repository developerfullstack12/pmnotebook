#	wp bp signup resend

Resend activation e-mail to a newly registered user.

## OPTIONS

&lt;signup-id&gt;
: Identifier for the signup. Can be a signup ID, an email address, or a user_login.

## EXAMPLE

    $ wp bp signup resend test@example.com
    Success: Email sent successfully.
