# wp bp activity spam

Spam an activity.

## OPTIONS

&lt;activity-id&gt;
: Identifier for the activity.

## EXAMPLES

	$ wp bp activity spam 500
	Success: Activity marked as spam.
	
	$ wp bp activity unham 165165
	Success: Activity marked as spam.
	
