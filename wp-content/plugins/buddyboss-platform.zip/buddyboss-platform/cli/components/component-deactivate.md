#	wp bp component deactivate

Deactivate a component.

## OPTIONS

&lt;component&gt;
: Name of the component to deactivate.

## EXAMPLE

	 $ wp bp component deactivate groups
	 Success: The Groups component has been deactivated.
