#	wp bp component activate

Activate a component.

## OPTIONS

&lt;component&gt;
: Name of the component to activate.

## EXAMPLE

    $ wp bp component activate groups
    Success: The Groups component has been activated.
